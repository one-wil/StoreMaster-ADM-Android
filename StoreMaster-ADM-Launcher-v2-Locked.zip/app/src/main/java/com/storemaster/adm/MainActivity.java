package com.storemaster.adm;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "storemaster_launcher";
    private EditText admUrl, shopUrl;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showLauncher();
    }

    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER); t.setPadding(12,12,12,12); return t;
    }
    private EditText input(String hint, String value) {
        EditText e = new EditText(this); e.setHint(hint); e.setText(value); e.setTextSize(15); e.setSingleLine(true);
        e.setTextColor(Color.DKGRAY); e.setHintTextColor(Color.GRAY); e.setPadding(24,12,24,12); e.setBackgroundColor(Color.WHITE); return e;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(16); b.setAllCaps(false); return b;
    }
    private CheckBox lockBox(String label, boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextSize(14);
        c.setTextColor(Color.WHITE);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setChecked(checked);
        c.setPadding(4, 0, 4, 0);
        return c;
    }

    private void showLauncher() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(30, 35, 30, 30);
        root.setBackgroundColor(Color.rgb(26,27,46));

        TextView title = text("StoreMaster ADM", 28);
        root.addView(title, new LinearLayout.LayoutParams(-1, 70));
        TextView sub = text("إعداد روابط لوحة الإدارة والبوتيك", 15);
        sub.setTextColor(Color.LTGRAY);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 55));

        admUrl = input("رابط ADM — https://...", prefs.getString("adm", ""));
        shopUrl = input("رابط البوتيك — https://...", prefs.getString("shop", ""));
        CheckBox admLock = lockBox("☑ رابط ADM مقفل", prefs.getBoolean("adm_locked", false));
        CheckBox shopLock = lockBox("☑ رابط البوتيك مقفل", prefs.getBoolean("shop_locked", false));

        admUrl.setEnabled(!admLock.isChecked());
        shopUrl.setEnabled(!shopLock.isChecked());

        root.addView(admUrl, new LinearLayout.LayoutParams(-1, 60));
        root.addView(admLock, new LinearLayout.LayoutParams(-1, 48));
        View gap1 = new View(this); root.addView(gap1, new LinearLayout.LayoutParams(-1, 14));
        root.addView(shopUrl, new LinearLayout.LayoutParams(-1, 60));
        root.addView(shopLock, new LinearLayout.LayoutParams(-1, 48));
        View gap = new View(this); root.addView(gap, new LinearLayout.LayoutParams(-1, 18));

        Button openAdm = button("🔐 دخول إلى ADM");
        Button openShop = button("🛍️ فتح البوتيك");
        Button save = button("💾 حفظ الإعدادات");
        root.addView(openAdm, new LinearLayout.LayoutParams(-1, 60));
        root.addView(new View(this), new LinearLayout.LayoutParams(-1, 12));
        root.addView(openShop, new LinearLayout.LayoutParams(-1, 60));
        root.addView(new View(this), new LinearLayout.LayoutParams(-1, 12));
        root.addView(save, new LinearLayout.LayoutParams(-1, 55));

        TextView note = text("بعد قفل الرابط، لا يمكن تعديله حتى يتم إلغاء القفل.", 13);
        note.setTextColor(Color.LTGRAY);
        root.addView(note, new LinearLayout.LayoutParams(-1, 65));

        admLock.setOnCheckedChangeListener((b, checked) -> {
            admUrl.setEnabled(!checked);
            prefs.edit().putBoolean("adm_locked", checked).apply();
            if (checked) saveUrls();
        });
        shopLock.setOnCheckedChangeListener((b, checked) -> {
            shopUrl.setEnabled(!checked);
            prefs.edit().putBoolean("shop_locked", checked).apply();
            if (checked) saveUrls();
        });
        save.setOnClickListener(v -> saveUrls());
        openAdm.setOnClickListener(v -> openUrl(admUrl.getText().toString().trim(), true));
        openShop.setOnClickListener(v -> openUrl(shopUrl.getText().toString().trim(), false));
        setContentView(root);
    }
    private void saveUrls() {
        prefs.edit().putString("adm", admUrl.getText().toString().trim()).putString("shop", shopUrl.getText().toString().trim()).apply();
        Toast.makeText(this, "تم حفظ الروابط", Toast.LENGTH_SHORT).show();
    }
    private void openUrl(String url, boolean adm) {
        if (url.isEmpty()) { Toast.makeText(this, adm ? "أدخل رابط ADM أولاً" : "أدخل رابط البوتيك أولاً", Toast.LENGTH_SHORT).show(); return; }
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://" + url;
        prefs.edit().putString(adm ? "adm" : "shop", url).apply();
        WebView w = new WebView(this); WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        w.setWebViewClient(new android.webkit.WebViewClient()); w.loadUrl(url); setContentView(w);
    }
    @Override public void onBackPressed() { showLauncher(); }
}
