package com.storemaster.adm;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private static final String PREFS = "storemaster_launcher";
    private static final String KEY_ALIAS = "StoreMasterPasswordKey";
    private EditText admUrl, shopUrl, passwordInput;
    private SharedPreferences prefs;

    private final int BG = Color.rgb(15, 17, 35);
    private final int CARD = Color.rgb(30, 33, 58);
    private final int CARD2 = Color.rgb(36, 39, 68);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(195, 198, 214);
    private final int BLUE = Color.rgb(67, 97, 238);
    private final int GREEN = Color.rgb(24, 168, 112);
    private final int GRAY = Color.rgb(82, 87, 113);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showLauncher();
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String s, float size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true);
        return t;
    }

    private EditText urlInput(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setTextColor(Color.rgb(30, 32, 45));
        e.setHintTextColor(Color.rgb(125, 128, 140));
        e.setHint("https://...");
        e.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        e.setPadding(18, 0, 18, 0);
        e.setBackground(rounded(Color.WHITE, 20));
        return e;
    }

    private EditText passwordInput(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setTextColor(Color.rgb(30, 32, 45));
        e.setHintTextColor(Color.rgb(125, 128, 140));
        e.setHint("كلمة مرور لوحة التحكم");
        e.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setPadding(16, 0, 16, 0);
        e.setBackground(rounded(Color.WHITE, 18));
        return e;
    }

    private CheckBox lockBox(String text, boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextSize(14);
        c.setTextColor(WHITE);
        c.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        c.setButtonTintList(new ColorStateList(
                new int[][] { new int[]{android.R.attr.state_checked}, new int[]{} },
                new int[] { BLUE, Color.rgb(150, 154, 170) }
        ));
        c.setChecked(checked);
        c.setPadding(0, 0, 2, 0);
        return c;
    }

    private Button actionButton(String value, int color, int height) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(17);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(true);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(12, 0, 12, 0);
        b.setBackground(rounded(color, 19));
        b.setStateListAnimator(null);
        return b;
    }

    private void addGap(LinearLayout root, int dp) {
        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, dp));
    }

    private void addSection(LinearLayout root, String title, EditText input, CheckBox lock) {
        TextView t = text(title, 17, true, WHITE);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        root.addView(t, new LinearLayout.LayoutParams(-1, 48));
        root.addView(input, new LinearLayout.LayoutParams(-1, 58));
        addGap(root, 7);
        root.addView(lock, new LinearLayout.LayoutParams(-1, 43));
    }

    private void addPasswordSection(LinearLayout root, CheckBox lock, ImageButton copy) {
        TextView title = text("كلمة مرور لوحة التحكم", 17, true, WHITE);
        title.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, 50));
        addGap(root, 4);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // Right: lock | Middle: password | Left: copy
        LinearLayout.LayoutParams lockLp = new LinearLayout.LayoutParams(72, 58);
        lockLp.setMargins(0, 0, 8, 0);
        row.addView(lock, lockLp);

        LinearLayout.LayoutParams passLp = new LinearLayout.LayoutParams(0, 58, 1f);
        row.addView(passwordInput, passLp);

        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(52, 58);
        copyLp.setMargins(8, 0, 0, 0);
        row.addView(copy, copyLp);

        root.addView(row, new LinearLayout.LayoutParams(-1, 58));
        addGap(root, 8);
    }

    private ImageButton copyButton() {
        ImageButton b = new ImageButton(this);
        b.setImageResource(android.R.drawable.ic_menu_copy);
        b.setContentDescription("نسخ كلمة المرور");
        b.setColorFilter(WHITE);
        b.setBackground(rounded(CARD2, 18));
        b.setPadding(14, 14, 14, 14);
        return b;
    }

    private void showLauncher() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(BG);
        root.setPadding(20, 22, 20, 20);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content.setPadding(2, 0, 2, 16);

        TextView title = text("StoreMaster ADM", 31, true, WHITE);
        title.setGravity(Gravity.CENTER);
        title.setAlpha(0f);
        title.setScaleX(0.78f);
        title.setScaleY(0.78f);
        content.addView(title, new LinearLayout.LayoutParams(-1, 66));

        TextView sub = text("إعداد روابط لوحة الإدارة والبوتيك", 16, false, MUTED);
        sub.setGravity(Gravity.CENTER);
        sub.setAlpha(0f);
        content.addView(sub, new LinearLayout.LayoutParams(-1, 46));
        addGap(content, 20);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 20, 18, 20);
        card.setBackground(rounded(CARD, 24));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setAlpha(0f);
        card.setTranslationY(28f);

        admUrl = urlInput(prefs.getString("adm", ""));
        shopUrl = urlInput(prefs.getString("shop", ""));
        passwordInput = passwordInput(decryptPassword(prefs.getString("password_enc", "")));

        CheckBox admLock = lockBox("قفل", prefs.getBoolean("adm_locked", false));
        CheckBox shopLock = lockBox("قفل", prefs.getBoolean("shop_locked", false));
        CheckBox passwordLock = lockBox("قفل", prefs.getBoolean("password_locked", false));
        ImageButton copyPassword = copyButton();

        addSection(card, "رابط لوحة الإدارة ADM", admUrl, admLock);
        addGap(card, 18);
        addSection(card, "رابط البوتيك", shopUrl, shopLock);
        addGap(card, 22);
        addPasswordSection(card, passwordLock, copyPassword);

        TextView secure = text("تُحفظ كلمة المرور محليًا بشكل مشفّر ولا تظهر كنص عادي.", 13, false, MUTED);
        secure.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        card.addView(secure, new LinearLayout.LayoutParams(-1, 36));

        content.addView(card, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(content, 24);

        Button openAdm = actionButton("دخول إلى ADM", BLUE, 62);
        Button openShop = actionButton("فتح البوتيك", GREEN, 62);
        Button save = actionButton("حفظ الإعدادات", GRAY, 58);
        openAdm.setAlpha(0f); openShop.setAlpha(0f); save.setAlpha(0f);

        content.addView(openAdm, new LinearLayout.LayoutParams(-1, 62));
        addGap(content, 14);
        content.addView(openShop, new LinearLayout.LayoutParams(-1, 62));
        addGap(content, 14);
        content.addView(save, new LinearLayout.LayoutParams(-1, 58));
        addGap(content, 18);

        TextView note = text("بعد قفل الرابط أو كلمة المرور، لن يمكن تعديلها حتى يتم إلغاء القفل.", 13, false, MUTED);
        note.setGravity(Gravity.CENTER);
        note.setAlpha(0f);
        content.addView(note, new LinearLayout.LayoutParams(-1, 52));

        scroll.addView(content, new ScrollView.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        admUrl.setEnabled(!admLock.isChecked());
        shopUrl.setEnabled(!shopLock.isChecked());
        passwordInput.setEnabled(!passwordLock.isChecked());

        admLock.setOnCheckedChangeListener((button, checked) -> {
            admUrl.setEnabled(!checked);
            prefs.edit().putBoolean("adm_locked", checked).apply();
            if (checked) saveSettings();
        });
        shopLock.setOnCheckedChangeListener((button, checked) -> {
            shopUrl.setEnabled(!checked);
            prefs.edit().putBoolean("shop_locked", checked).apply();
            if (checked) saveSettings();
        });
        passwordLock.setOnCheckedChangeListener((button, checked) -> {
            passwordInput.setEnabled(!checked);
            prefs.edit().putBoolean("password_locked", checked).apply();
            if (checked) saveSettings();
        });

        copyPassword.setOnClickListener(v -> copyPasswordToClipboard());
        save.setOnClickListener(v -> saveSettings());
        openAdm.setOnClickListener(v -> openUrl(admUrl.getText().toString().trim(), true));
        openShop.setOnClickListener(v -> openUrl(shopUrl.getText().toString().trim(), false));

        setContentView(root);

        // Dynamic opening: title first, then the rest of the interface.
        title.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(650).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        title.postDelayed(() -> {
            sub.animate().alpha(1f).setDuration(380).start();
            card.animate().alpha(1f).translationY(0f).setDuration(520)
                    .setInterpolator(new AccelerateDecelerateInterpolator()).start();
        }, 500);
        title.postDelayed(() -> {
            openAdm.animate().alpha(1f).setDuration(280).start();
            openShop.animate().alpha(1f).setDuration(280).start();
            save.animate().alpha(1f).setDuration(280).start();
            note.animate().alpha(1f).setDuration(280).start();
        }, 900);
    }

    private void saveSettings() {
        String password = passwordInput == null ? "" : passwordInput.getText().toString();
        String encrypted = encryptPassword(password);
        prefs.edit()
                .putString("adm", admUrl.getText().toString().trim())
                .putString("shop", shopUrl.getText().toString().trim())
                .putString("password_enc", encrypted)
                .apply();
        Toast.makeText(this, "تم حفظ الإعدادات بنجاح", Toast.LENGTH_SHORT).show();
    }

    private void copyPasswordToClipboard() {
        String password = passwordInput.getText().toString();
        if (password.isEmpty()) {
            password = decryptPassword(prefs.getString("password_enc", ""));
        }
        if (password.isEmpty()) {
            Toast.makeText(this, "أدخل كلمة المرور أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("StoreMaster ADM", password));
        Toast.makeText(this, "تم نسخ كلمة المرور", Toast.LENGTH_SHORT).show();
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return kg.generateKey();
    }

    private String encryptPassword(String plain) {
        if (plain == null || plain.isEmpty()) return "";
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] encrypted = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            byte[] iv = cipher.getIV();
            return Base64.NO_WRAP.encodeToString(iv) + ":" + Base64.NO_WRAP.encodeToString(encrypted);
        } catch (Exception e) {
            return "";
        }
    }

    private String decryptPassword(String stored) {
        if (stored == null || stored.isEmpty() || !stored.contains(":")) return "";
        try {
            String[] parts = stored.split(":", 2);
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] data = Base64.decode(parts[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(data), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private void openUrl(String url, boolean adm) {
        if (url.isEmpty()) {
            Toast.makeText(this, adm ? "أدخل رابط ADM أولاً" : "أدخل رابط البوتيك أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://" + url;
        prefs.edit().putString(adm ? "adm" : "shop", url).apply();

        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        w.setWebViewClient(new android.webkit.WebViewClient());
        w.loadUrl(url);
        setContentView(w);
    }

    @Override public void onBackPressed() { showLauncher(); }
}
