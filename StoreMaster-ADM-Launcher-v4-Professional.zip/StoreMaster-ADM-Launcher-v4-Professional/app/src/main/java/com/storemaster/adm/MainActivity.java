package com.storemaster.adm;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "storemaster_launcher";
    private EditText admUrl, shopUrl;
    private SharedPreferences prefs;

    private final int BG = Color.rgb(18, 20, 38);
    private final int CARD = Color.rgb(31, 34, 58);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(190, 194, 210);
    private final int BLUE = Color.rgb(67, 97, 238);
    private final int GREEN = Color.rgb(24, 168, 112);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showLauncher();
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView label(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(WHITE);
        t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true);
        return t;
    }

    private EditText urlInput(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setTextColor(Color.rgb(35, 37, 48));
        e.setHintTextColor(Color.rgb(125, 128, 140));
        e.setHint("https://...");
        e.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        e.setPadding(18, 0, 18, 0);
        e.setBackground(rounded(Color.WHITE, 18));
        e.setSelectAllOnFocus(false);
        return e;
    }

    private CheckBox lockBox(String text, boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextSize(15);
        c.setTextColor(WHITE);
        c.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        c.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        c.setButtonTintList(new android.content.res.ColorStateList(
                new int[][] { new int[]{android.R.attr.state_checked}, new int[]{} },
                new int[] { BLUE, Color.rgb(150, 154, 170) }
        ));
        c.setChecked(checked);
        c.setPadding(0, 0, 4, 0);
        return c;
    }

    private Button actionButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(true);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(12, 0, 12, 0);
        b.setBackground(rounded(color, 18));
        b.setStateListAnimator(null);
        return b;
    }

    private void addGap(LinearLayout root, int dp) {
        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, dp));
    }

    private void addSection(LinearLayout root, String title, EditText input, CheckBox lock) {
        TextView t = label(title, 16);
        t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        root.addView(t, new LinearLayout.LayoutParams(-1, 42));
        root.addView(input, new LinearLayout.LayoutParams(-1, 58));
        root.addView(lock, new LinearLayout.LayoutParams(-1, 50));
    }

    private void showLauncher() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(BG);
        root.setPadding(24, 24, 24, 22);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = label("StoreMaster ADM", 28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        content.addView(title, new LinearLayout.LayoutParams(-1, 58));

        TextView sub = label("إعداد روابط لوحة الإدارة والبوتيك", 15);
        sub.setTextColor(MUTED);
        sub.setGravity(Gravity.CENTER);
        content.addView(sub, new LinearLayout.LayoutParams(-1, 40));
        addGap(content, 14);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 16, 18, 16);
        card.setBackground(rounded(CARD, 22));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        admUrl = urlInput(prefs.getString("adm", ""));
        shopUrl = urlInput(prefs.getString("shop", ""));
        CheckBox admLock = lockBox("قفل رابط ADM", prefs.getBoolean("adm_locked", false));
        CheckBox shopLock = lockBox("قفل رابط البوتيك", prefs.getBoolean("shop_locked", false));

        addSection(card, "رابط لوحة الإدارة ADM", admUrl, admLock);
        addGap(card, 8);
        addSection(card, "رابط البوتيك", shopUrl, shopLock);

        content.addView(card, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(content, 18);

        Button openAdm = actionButton("دخول إلى ADM", BLUE);
        Button openShop = actionButton("فتح البوتيك", GREEN);
        Button save = actionButton("حفظ الإعدادات", Color.rgb(78, 82, 105));

        content.addView(openAdm, new LinearLayout.LayoutParams(-1, 62));
        addGap(content, 10);
        content.addView(openShop, new LinearLayout.LayoutParams(-1, 62));
        addGap(content, 10);
        content.addView(save, new LinearLayout.LayoutParams(-1, 58));
        addGap(content, 12);

        TextView note = label("بعد قفل الرابط، لن يمكن تعديله حتى يتم إلغاء القفل.", 13);
        note.setTextColor(MUTED);
        note.setGravity(Gravity.CENTER);
        content.addView(note, new LinearLayout.LayoutParams(-1, 46));

        scroll.addView(content, new ScrollView.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        admUrl.setEnabled(!admLock.isChecked());
        shopUrl.setEnabled(!shopLock.isChecked());

        admLock.setOnCheckedChangeListener((b, checked) -> {
            admUrl.setEnabled(!checked);
            prefs.edit().putBoolean("adm_locked", checked).apply();
            if (checked) saveUrls();
        });
        shopLock.setOnCheckedChangeListener((b, checked) -> {
            shopUrl.setEnabled(!checked);
            prefs.edit().putBoolean("shop_locked", checked).apply();
            if (checked) saveUrls();
        });
        save.setOnClickListener(v -> saveUrls());
        openAdm.setOnClickListener(v -> openUrl(admUrl.getText().toString().trim(), true));
        openShop.setOnClickListener(v -> openUrl(shopUrl.getText().toString().trim(), false));

        setContentView(root);
    }

    private void saveUrls() {
        prefs.edit()
                .putString("adm", admUrl.getText().toString().trim())
                .putString("shop", shopUrl.getText().toString().trim())
                .apply();
        Toast.makeText(this, "تم حفظ الروابط بنجاح", Toast.LENGTH_SHORT).show();
    }

    private void openUrl(String url, boolean adm) {
        if (url.isEmpty()) {
            Toast.makeText(this, adm ? "أدخل رابط ADM أولاً" : "أدخل رابط البوتيك أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://" + url;
        prefs.edit().putString(adm ? "adm" : "shop", url).apply();

        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        w.setWebViewClient(new android.webkit.WebViewClient());
        w.loadUrl(url);
        setContentView(w);
    }

    @Override public void onBackPressed() { showLauncher(); }
}
