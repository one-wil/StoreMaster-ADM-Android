package com.storemaster.adm;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private static final String PREFS = "storemaster_launcher";
    private static final String KEY_ALIAS = "StoreMasterPasswordKey";
    private EditText admUrl, shopUrl, passwordInput;
    private SharedPreferences prefs;

    private final int BG = Color.rgb(15, 17, 35);
    private final int CARD = Color.rgb(30, 33, 58);
    private final int CARD2 = Color.rgb(42, 46, 78);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(195, 198, 214);
    private final int BLUE = Color.rgb(67, 97, 238);
    private final int GREEN = Color.rgb(24, 168, 112);
    private final int GRAY = Color.rgb(82, 87, 113);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showLauncher();
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String s, float size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return t;
    }

    private EditText urlInput(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setTextColor(Color.rgb(30, 32, 45));
        e.setHintTextColor(Color.rgb(125, 128, 140));
        e.setHint("https://...");
        e.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        e.setPadding(18, 0, 18, 0);
        e.setBackground(rounded(Color.WHITE, 18));
        return e;
    }

    private EditText passwordField(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setTextColor(Color.rgb(30, 32, 45));
        e.setHintTextColor(Color.rgb(125, 128, 140));
        e.setHint("كلمة مرور لوحة التحكم");
        e.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setPadding(16, 0, 16, 0);
        e.setBackground(rounded(Color.WHITE, 17));
        return e;
    }

    private CheckBox lockBox(boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText("قفل");
        c.setTextSize(14);
        c.setTextColor(WHITE);
        c.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        c.setButtonTintList(new ColorStateList(
                new int[][] { new int[]{android.R.attr.state_checked}, new int[]{} },
                new int[] { BLUE, Color.rgb(150, 154, 170) }
        ));
        c.setChecked(checked);
        c.setPadding(0, 0, 0, 0);
        c.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return c;
    }

    private Button actionButton(String value, int color, int height) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(17);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(true);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(12, 0, 12, 0);
        b.setBackground(rounded(color, 18));
        b.setStateListAnimator(null);
        return b;
    }

    private void addGap(LinearLayout root, int dp) {
        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, dp));
    }

    /** A clean section: title, generous gap, input, then lock on its own line. */
    private void addUrlSection(LinearLayout root, String title, EditText input, CheckBox lock) {
        TextView t = text(title, 17, true, WHITE);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setPadding(0, 0, 2, 0);
        root.addView(t, new LinearLayout.LayoutParams(-1, 48));
        addGap(root, 14);
        root.addView(input, new LinearLayout.LayoutParams(-1, 58));
        addGap(root, 8);

        LinearLayout lockRow = new LinearLayout(this);
        lockRow.setOrientation(LinearLayout.HORIZONTAL);
        lockRow.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        lockRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        lockRow.addView(lock, new LinearLayout.LayoutParams(78, 42));
        root.addView(lockRow, new LinearLayout.LayoutParams(-1, 42));
    }

    /** Password row: lock on the right, field in the middle, copy on the left. */
    private void addPasswordSection(LinearLayout root, EditText field, CheckBox lock, ImageButton copy) {
        TextView title = text("كلمة مرور لوحة التحكم", 17, true, WHITE);
        title.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, 48));
        addGap(root, 14);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout.LayoutParams lockLp = new LinearLayout.LayoutParams(66, 56);
        lockLp.setMargins(0, 0, 10, 0);
        row.addView(lock, lockLp);

        LinearLayout.LayoutParams fieldLp = new LinearLayout.LayoutParams(0, 56, 1f);
        row.addView(field, fieldLp);

        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(52, 56);
        copyLp.setMargins(10, 0, 0, 0);
        row.addView(copy, copyLp);

        root.addView(row, new LinearLayout.LayoutParams(-1, 56));
        addGap(root, 12);
    }

    private ImageButton copyButton() {
        ImageButton b = new ImageButton(this);
        b.setImageResource(com.storemaster.adm.R.drawable.ic_copy);
        b.setContentDescription("نسخ كلمة المرور");
        b.setColorFilter(WHITE);
        b.setBackground(rounded(CARD2, 17));
        b.setPadding(13, 13, 13, 13);
        b.setScaleType(ImageButton.ScaleType.CENTER_INSIDE);
        return b;
    }

    private void showLauncher() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(BG);
        root.setPadding(18, 16, 18, 20);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content.setPadding(0, dp(44), 0, dp(20));

        // Stage 1: brand animation. Other stages are INVISIBLE until their turn.
        TextView title = text("StoreMaster ADM", 30, true, WHITE);
        title.setGravity(Gravity.CENTER);
        title.setAlpha(0f);
        title.setTranslationY(-28f);
        title.setScaleX(0.88f);
        title.setScaleY(0.88f);
        content.addView(title, new LinearLayout.LayoutParams(-1, 92));

        addGap(content, 10);

        TextView sub = text("إعداد روابط لوحة الإدارة والبوتيك", 16, false, MUTED);
        sub.setGravity(Gravity.CENTER);
        sub.setVisibility(View.INVISIBLE);
        content.addView(sub, new LinearLayout.LayoutParams(-1, 52));
        addGap(content, 28);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 22, 18, 22);
        card.setBackground(rounded(CARD, 23));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setVisibility(View.INVISIBLE);

        admUrl = urlInput(prefs.getString("adm", ""));
        shopUrl = urlInput(prefs.getString("shop", ""));
        passwordInput = passwordField(decryptPassword(prefs.getString("password_enc", "")));

        CheckBox admLock = lockBox(prefs.getBoolean("adm_locked", false));
        CheckBox shopLock = lockBox(prefs.getBoolean("shop_locked", false));
        CheckBox passwordLock = lockBox(prefs.getBoolean("password_locked", false));
        ImageButton copyPassword = copyButton();

        addUrlSection(card, "رابط لوحة الإدارة ADM", admUrl, admLock);
        addGap(card, 20);
        addUrlSection(card, "رابط البوتيك", shopUrl, shopLock);
        addGap(card, 24);
        addPasswordSection(card, passwordInput, passwordLock, copyPassword);

        TextView secure = text("تُحفظ كلمة المرور محليًا بشكل مشفّر ولا تظهر كنص عادي.", 13, false, MUTED);
        secure.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        card.addView(secure, new LinearLayout.LayoutParams(-1, 40));

        content.addView(card, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(content, 28);

        // Stage 4: compact buttons with side margins, not full-screen width.
        Button openAdm = actionButton("دخول إلى ADM", BLUE, 58);
        Button openShop = actionButton("فتح البوتيك", GREEN, 58);
        Button save = actionButton("حفظ الإعدادات", GRAY, 56);
        TextView note = text("بعد قفل الرابط أو كلمة المرور، لن يمكن تعديلها حتى يتم إلغاء القفل.", 13, false, MUTED);
        note.setGravity(Gravity.CENTER);

        openAdm.setVisibility(View.INVISIBLE);
        openShop.setVisibility(View.INVISIBLE);
        save.setVisibility(View.INVISIBLE);
        note.setVisibility(View.INVISIBLE);

        int buttonWidth = dp(330);
        content.addView(openAdm, centeredParams(buttonWidth, 58));
        addGap(content, 14);
        content.addView(openShop, centeredParams(buttonWidth, 58));
        addGap(content, 14);
        content.addView(save, centeredParams(buttonWidth, 56));
        addGap(content, 18);
        content.addView(note, new LinearLayout.LayoutParams(-1, 48));

        scroll.addView(content, new ScrollView.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        admUrl.setEnabled(!admLock.isChecked());
        shopUrl.setEnabled(!shopLock.isChecked());
        passwordInput.setEnabled(!passwordLock.isChecked());

        admLock.setOnCheckedChangeListener((button, checked) -> {
            admUrl.setEnabled(!checked);
            prefs.edit().putBoolean("adm_locked", checked).apply();
            if (checked) saveSettings();
        });
        shopLock.setOnCheckedChangeListener((button, checked) -> {
            shopUrl.setEnabled(!checked);
            prefs.edit().putBoolean("shop_locked", checked).apply();
            if (checked) saveSettings();
        });
        passwordLock.setOnCheckedChangeListener((button, checked) -> {
            passwordInput.setEnabled(!checked);
            prefs.edit().putBoolean("password_locked", checked).apply();
            if (checked) saveSettings();
        });

        copyPassword.setOnClickListener(v -> copyPasswordToClipboard());
        save.setOnClickListener(v -> saveSettings());
        openAdm.setOnClickListener(v -> openUrl(admUrl.getText().toString().trim(), true));
        openShop.setOnClickListener(v -> openUrl(shopUrl.getText().toString().trim(), false));

        setContentView(root);

        // Smooth opening: title first, then subtitle, card, then buttons.
        title.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(850).setInterpolator(new DecelerateInterpolator()).start();

        title.postDelayed(() -> reveal(sub, 420, 0f, 14f), 900);
        title.postDelayed(() -> reveal(card, 560, 0f, 22f), 1350);
        title.postDelayed(() -> {
            reveal(openAdm, 280, 0f, 18f);
            openAdm.postDelayed(() -> reveal(openShop, 280, 0f, 18f), 90);
            openShop.postDelayed(() -> reveal(save, 280, 0f, 18f), 180);
            save.postDelayed(() -> reveal(note, 280, 0f, 10f), 270);
        }, 1950);
    }

    private void reveal(View v, long duration, float alphaFrom, float yFrom) {
        v.setVisibility(View.VISIBLE);
        v.setAlpha(alphaFrom);
        v.setTranslationY(yFrom);
        v.animate().alpha(1f).translationY(0f).setDuration(duration)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private LinearLayout.LayoutParams centeredParams(int width, int height) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(width), height);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void saveSettings() {
        String password = passwordInput == null ? "" : passwordInput.getText().toString();
        String encrypted = encryptPassword(password);
        prefs.edit()
                .putString("adm", admUrl.getText().toString().trim())
                .putString("shop", shopUrl.getText().toString().trim())
                .putString("password_enc", encrypted)
                .apply();
        Toast.makeText(this, "تم حفظ الإعدادات بنجاح", Toast.LENGTH_SHORT).show();
    }

    private void copyPasswordToClipboard() {
        String password = passwordInput.getText().toString();
        if (password.isEmpty()) password = decryptPassword(prefs.getString("password_enc", ""));
        if (password.isEmpty()) {
            Toast.makeText(this, "أدخل كلمة المرور أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("StoreMaster ADM", password));
        Toast.makeText(this, "تم نسخ كلمة المرور", Toast.LENGTH_SHORT).show();
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return kg.generateKey();
    }

    private String encryptPassword(String plain) {
        if (plain == null || plain.isEmpty()) return "";
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] encrypted = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            byte[] iv = cipher.getIV();
            return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private String decryptPassword(String stored) {
        if (stored == null || stored.isEmpty() || !stored.contains(":")) return "";
        try {
            String[] parts = stored.split(":", 2);
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] data = Base64.decode(parts[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(data), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private void openUrl(String url, boolean adm) {
        if (url.isEmpty()) {
            Toast.makeText(this, adm ? "أدخل رابط ADM أولاً" : "أدخل رابط البوتيك أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://" + url;
        prefs.edit().putString(adm ? "adm" : "shop", url).apply();

        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        w.setWebViewClient(new android.webkit.WebViewClient());
        w.loadUrl(url);
        setContentView(w);
    }

    @Override public void onBackPressed() { showLauncher(); }
}
